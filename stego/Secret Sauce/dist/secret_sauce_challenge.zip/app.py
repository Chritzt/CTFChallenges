import os
print('Starting our production app...')
print('Starting our production app safely...')
